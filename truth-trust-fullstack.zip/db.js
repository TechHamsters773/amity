import Database from 'better-sqlite3';
import fs from 'fs';

const DB_PATH = './data.sqlite';
export function getDb() {
  const db = new Database(DB_PATH);
  db.pragma('journal_mode = WAL');
  return db;
}

// One-time init if needed
if (process.argv.includes('--init')) {
  const db = getDb();
  const schema = fs.readFileSync('./schema.sql', 'utf8');
  db.exec(schema);
  console.log('Database initialized.');
}
