import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import fetch from 'node-fetch';
import cheerio from 'cheerio';
import crypto from 'crypto';
import { getDb } from './db.js';
import fs from 'fs';

const app = express();
const db = getDb();

// Ensure schema
const schema = fs.readFileSync('./schema.sql', 'utf8');
db.exec(schema);

app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(morgan('dev'));
app.use(express.static('public'));

// ---------- Utils ----------
const b64url = (buf) => buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
async function shortHash(str) {
  const h = crypto.createHash('sha256').update(str).digest();
  return b64url(h).slice(0, 10);
}

function extractTextFromHtml(html) {
  const $ = cheerio.load(html);
  ['script','style','noscript','header','footer','nav','form','aside'].forEach(s => $(s).remove());
  const text = $('body').text().replace(/\s+/g, ' ').trim();
  return text;
}

function scoreText(text) {
  let score = 80;
  const reasons = [];
  const t = text || '';
  const words = t.trim().split(/\s+/).filter(Boolean);
  if (words.length < 8) { score -= 20; reasons.push('Too short to assess reliably.'); }
  const capsWords = (t.match(/\b[A-Z]{4,}\b/g) || []).length;
  if (capsWords >= 3) { score -= Math.min(25, capsWords * 3); reasons.push('Many ALL-CAPS words.'); }
  const clickbait = /(you won't believe|shocking|breaking|exposed|miracle cure|what happens next|guaranteed)/i;
  if (clickbait.test(t)) { score -= 20; reasons.push('Contains common clickbait phrase(s).'); }
  const bangs = (t.match(/[!?]/g) || []).length;
  if (bangs > 8) { score -= 15; reasons.push('Excessive punctuation (?!).'); }
  if (/\b\d{2,}%\b/.test(t) && !/http/i.test(t)) { score -= 10; reasons.push('Large percentage claim without a source.'); }
  let domainFlag = false;
  const urlMatch = t.match(/https?:\/\/[^\s]+/i);
  if (urlMatch) {
    try {
      const u = new URL(urlMatch[0]);
      const susTlds = /(\.zip|\.mov|\.click|\.info)$/i;
      if (susTlds.test(u.hostname)) { domainFlag = true; reasons.push('Suspicious top-level domain.'); }
      if (/\d{5,}/.test(u.hostname)) { domainFlag = true; reasons.push('Domain looks auto-generated.'); }
      if (u.searchParams.toString().length > 60) { domainFlag = true; reasons.push('Very long tracking query in URL.'); }
    } catch {}
  }
  if (domainFlag) score -= 15;
  score = Math.max(1, Math.min(99, score));
  let verdict = 'Likely reliable';
  if (score < 60 && score >= 40) verdict = 'Uncertain';
  if (score < 40) verdict = 'Potential misinformation';
  return { score, reasons, verdict };
}

// ---------- API: Fake News Analyze ----------
app.post('/api/analyze', async (req, res) => {
  try {
    const { text, url } = req.body || {};
    let content = text || '';

    if (!content && url) {
      try {
        const r = await fetch(url, { redirect: 'follow' });
        const html = await r.text();
        content = extractTextFromHtml(html).slice(0, 50000);
      } catch (e) {
        return res.status(400).json({ error: 'Failed to fetch URL. Provide text instead.', detail: String(e) });
      }
    }
    if (!content || content.trim().length === 0) {
      return res.status(400).json({ error: 'Provide `text` or `url`.' });
    }
    const result = scoreText(content);
    res.json({ ok: true, ...result });
  } catch (e) {
    res.status(500).json({ error: 'Analyze failed', detail: String(e) });
  }
});

// ---------- API: Donations CRUD ----------
app.get('/api/donations', (req, res) => {
  const rows = db.prepare('SELECT * FROM donations ORDER BY ts DESC').all();
  res.json({ ok: true, rows });
});

app.post('/api/donations', async (req, res) => {
  try {
    const { donor = 'Anonymous', amount, category, note = '' } = req.body || {};
    const amt = Number(amount);
    if (!(amt > 0)) return res.status(400).json({ error: 'Amount must be > 0' });
    if (!category) return res.status(400).json({ error: 'Category is required' });

    const ts = Date.now();
    const txnId = Math.random().toString(36).slice(2, 9).toUpperCase();
    const hash = await shortHash([ts, donor, amt, category, note, txnId].join('|'));

    const stmt = db.prepare('INSERT INTO donations (ts, donor, amount, category, note, txn_id, hash) VALUES (?, ?, ?, ?, ?, ?, ?)');
    const info = stmt.run(ts, donor, amt, category, note, txnId, hash);
    const row = db.prepare('SELECT * FROM donations WHERE id = ?').get(info.lastInsertRowid);
    res.json({ ok: true, row });
  } catch (e) {
    res.status(500).json({ error: 'Insert failed', detail: String(e) });
  }
});

app.delete('/api/donations/:id', (req, res) => {
  const id = Number(req.params.id);
  const info = db.prepare('DELETE FROM donations WHERE id = ?').run(id);
  res.json({ ok: true, deleted: info.changes });
});

// ---------- API: Summaries & Exports ----------
app.get('/api/donations/summary', (req, res) => {
  const rows = db.prepare('SELECT category, SUM(amount) as total FROM donations GROUP BY category').all();
  const total = db.prepare('SELECT SUM(amount) as total FROM donations').get().total || 0;
  res.json({ ok: true, total, byCategory: rows });
});

app.get('/api/ledger.csv', (req, res) => {
  const rows = db.prepare('SELECT * FROM donations ORDER BY ts DESC').all();
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="donations.csv"');
  const header = ['date','donor','amount','category','note','txn_id','hash'];
  const esc = (s='') => '"' + String(s).replace(/"/g, '""') + '"';
  const csv = [header.join(',')].concat(rows.map(r => [
    new Date(r.ts).toISOString(), r.donor, r.amount, r.category, r.note or '', r.txn_id, r.hash
  ].map(esc).join(','))).join('\n');
  res.send(csv);
});

// ---------- Start ----------
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
